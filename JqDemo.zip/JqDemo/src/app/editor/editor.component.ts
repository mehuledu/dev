import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-editor',
  templateUrl: './editor.component.html',
  styleUrls: ['./editor.component.css']
})
export class EditorComponent implements OnInit {

  public myProp: string;

  constructor() { }

  ngOnInit() {
    this.myProp = 'Init';
    console.log('Init');
  }

  public action1() {
    this.myProp = 'Act1';
    console.log('Act1');
  }

  public action2() {
    this.myProp = 'Act2';
    console.log('Act2');
  }

}
