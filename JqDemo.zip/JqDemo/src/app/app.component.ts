import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { jqxDockingLayoutComponent } from 'jqwidgets-framework/jqwidgets-ts/angular_jqxdockinglayout';

import 'jqwidgets-framework';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {

  @ViewChild('dockingLayoutReference') myDockingLayout: jqxDockingLayoutComponent;

  /**
   * jqxDockingLayout initial settings
   */
  dockingLayoutSettings: jqwidgets.DockingLayoutOptions = {
    width: 988,
    height: 686,
    layout: this.generateLayout()
  };

  constructor() { }

  ngAfterViewInit(): void {
    // Create jqxDockingLayout
    this.myDockingLayout.createComponent(this.dockingLayoutSettings);
  };

  /**
   * Generate the default layout
   */
  generateLayout(): any {
    const layout = [{
      type: 'layoutGroup',
      orientation: 'horizontal',
      items: [{
        type: 'layoutGroup',
        orientation: 'vertical',
        width: '70%',
        items: [{
          type: 'documentGroup',
          height: '100%',
          minHeight: '100%',
          items: [{
            type: 'documentPanel',
            title: 'Editor',
            contentContainer: 'EditorPanel'

          }]
        }]
      }, {
        type: 'layoutGroup',
        orientation: 'vertical',
        width: '30%',
        items: [{
          type: 'tabbedGroup',
          height: '50%',
          items: [{
            type: 'layoutPanel',
            title: 'Properties',
            contentContainer: 'PropertiesPanel'
          }]
        },
        {
          type: 'tabbedGroup',
          height: '50%',
          items: [{
            type: 'layoutPanel',
            title: 'Explorer',
            contentContainer: 'ExplorerPanel'
          }]
        }
        ]
      }]
    }];

    return layout;
  }

}
